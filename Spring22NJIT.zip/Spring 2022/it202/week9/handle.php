<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Handle form</title>
</head>
<body>
    <p>
<?php
# Script to handle the incoming form data
# variables to hold data
$name = $_REQUEST['name'];
$service = $_REQUEST['service'];
$appointments = $_REQUEST['appointments'];
$price = $_REQUEST['price'];
$tax = $_REQUEST['tax'];
$cost = ($price*$appointments);
$cost += $cost*($tax/100);
?>
    <strong><?php echo $name ?>,</strong> you have 
    <strong><?php echo $appointments ?></strong> appointments for the following procedures
    <strong><?php echo $service ?></strong> at the price of <strong>$<?php echo number_format($price, 2, '.', ',') ?></strong>
    per visit. With a tax rate of <strong><?php echo $tax ?>%</strong>. The total cost including
    tax is <strong>$<?php echo number_format($cost, 2, '.', ',') ?></strong>.

    </p>
</body>
</html>