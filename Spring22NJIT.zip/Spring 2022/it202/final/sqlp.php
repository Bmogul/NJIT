<?php 
// mysqli_connect_erno()
// if successful, database failed to be conntcted to

// mysqli_fetch_all()
// fetches all result rows of a table
// numerical array, associative array or both

// mysqli_fetch_array()
// feteches a result row of a table
// numerical array, associative array or both

// mysqli_fetch_assoc()
// fetches a result row of a table
// associatve array

// mysqli_fetch_field()
// returns next field of result set
// does not return coulmns data

// mysqli_fetch_fields()
// returns an array of objects represnting fields in a result set

// mysqli_fetch_object()
// returns the current row of a result set as an object

// mysqli_fetch_row()
// fetches result row as a numerical array

// $mysqli_close() OR $mysqli->close()
// closes connection

// GET VS POST
// GET
// request data from specifeid resource, can be cashed
// remain in browser histoyr, can be bookmarked
// mever be used when deeling with sensitive dat
// have length restrictions
// request are only used to request data(not modify)

// POST
// send daat to server to create/update a resource
// requests are never cached
// do not remain in brower history
// cannot be bookmarked
// no data length restrictions

// Sessions and Cookies
// Cookies
    // store data in usrs browser as persistent cookie
        // Persisten cookie
                // specified expiry date
                // persistent in browser's cookie file until expiry date
                // is reached
    // each request to the server includes this data
// Sessiosn
    // store data on the server also known as session cookies
        // session cookies
            // no expiry dates
        // alternative to cookies, usially a file or a database record

// Error handling
// HTML
    // check source code, use validation tool, use browser debugger
    // test page in different browsers
// PHP
    // Exceptopn throw
        // try catch finally / try catch
    // end every statemet with semiclolr, balance every quote parentheses and braces
    // consistent with type of quotation marks used
    // escape cahracters when needed
// SQL
    // make sure query claueses are in right order
    // make sure coulmns are propperly named in queris

// Datatypes in Databasees
// BIT
    // single bit of boolena val
    // boolean or bool
// BLOB
    // large binary object(eg. image)
// CHAR(n)
    // a FIXED number of charactes
// DATE
    // TIME and DATETIME
// FLOAT
    // represents decimal, DOUBLE and DECIMAL
// INT
    // whoile num
// VARCHAR(n)
    // varibale num if character of max len n
// ENUM(val1, val2)
    // string that can only have value from list
// SET(val1, val2)
    // string that can have 0 or more vals from list

// ECHO
// echo "stuff or echo("Stuff")
// echo nl2br("Hello\nWorld") - allows for newlinec harcats
// use . for string concat

// 3-tired arch
// Presentaiotn
    // user interface, top most level, translates tasks and results 
    // to something user can udnerstand
// Application
    // processes commands, makes logical desciions wuth
    // user input, performs rvalusiton and caclulations
// Databse
    // data stored and registerd unto databse adn passes
    // back to application with passes to presnetiont layer

// PHP sorting
// sort()
    // ascending order
// rsort()
    // descending order
// asort()
    // associative asceing , accorunf the value
// ksort()
    // associative asceing , accorunf the key
// arsort()
    // associative descind , accorunf the value
// krsort()
    // associative descind , accorunf the key

// TRANSMISTON OF FORM DATA IN PHP
// $_REQUEST['name of form']
    // before resuest is used, the form must have the GET or POST methods


?>