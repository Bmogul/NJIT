const users = [
    {
        fname: "name",
        lname: "name",
        password: "Password@12",
        phoneNum: "555-555-5555",
        id: "123456"
    },
    {
        fname: "John",
        lname: "Doe",
        password: "Password#12",
        phoneNum: "555-555-5555",
        id: "654321"
    },
    {
        fname: "Burhanuddin",
        lname: "Mogul",
        password: "Password$12",
        phoneNum: "555-555-5555",
        id: "012345"
    },
    {
        fname: "jacob",
        lname: "martin",
        password: "Password$123",
        phoneNum: "555-555-5555",
        id: "123457"
    },
    {
        fname: "Ryan",
        lname: "Martin",
        password: "Password$123",
        phoneNum: "555-555-5555",
        id: "123458"
    },
    {
        fname: "Fred",
        lname: "Shoe",
        password: "Bassword$123",
        phoneNum: "111-555-5555",
        id: "123459"
    },
    {
        fname: "Ryan",
        lname: "Phillip",
        password: "Bassword$123",
        phoneNum: "111-555-5555",
        id: "123450"
    },
    {
        fname: "Martin",
        lname: "Martin",
        password: "Bassword$123",
        phoneNum: "111-555-5555",
        id: "666666"
    }
]

const emailReq = document.getElementById('emailreq')

const fname = document.getElementById('fname');
const lname = document.getElementById('lname');
const password = document.getElementById('psswd');
const id = document.getElementById('idnum');
const phone = document.getElementById('phone');
const email = document.getElementById('email');

const dropdown = document.getElementById('options')

const submit = document.getElementById('submitb')


const emailreq = () => {
    if(emailReq.style.visibility != "visible"){
        emailReq.style.visibility = "visible"
        email.classList.add("required")
    }else{
        emailReq.style.visibility = "hidden"
        email.classList.remove("required")
    }
    console.log(emailReq.style.visibility)
}

const validate = (form) =>{
    if(!fname.value){
        alert("No First Name given")
        fname.focus()
        return false
    }
    if(!lname.value){
        alert("No Last Name given")
        lname.focus()
        return false
    }
    if(!password.value){
        alert("No Password given")
        password.focus()
        return false
    }
    if(!id.value){
        alert("No ID given")
        id.focus()
        return false
    }
    if(!phone.value){
        alert("No Phone Number given")
        phone.focus()
        return false
    }
    if(!email.value && email.classList.contains('required')){
        alert("No Email given")
        email.focus()
        return false
    }

    if(password.value.length > 12 ){
        alert("Password too long, max length 12")
        password.focus()
        return false
    }else if(!/[A-Z]+/.test(password.value) || !/[^A-Za-z0-9]+/.test(password.value) || !/[0-9]+/.test(password.value)){
        alert("Password must contain at least one capital letter, at least one special character and at least one digit")
        password.focus()
        return false
    }

    if(!/^[0-9]*$/.test(id.value) || id.value.length != 6){
        alert("ID must be 6 digits")
        id.focus()
        return false
    }

    if(!/^[0-9]{3}[- ][0-9]{3}[- ][0-9]{4}$/.test(phone.value)){
        alert("Phone number must be 10 digits seperated by - or ' '")
        phone.focus()
        return false;
    }

    if(!/@[a-zA-Z_]+\.[a-zA-Z]{2,4}$/.test(email.value) && email.classList.contains('required')){
        alert("Invalid email address")
        email.focus()
        return false;
    }

    return true
}

const verify = () =>{
    verified = false
    users.forEach(user => {
        if(user.fname == fname.value && user.lname == lname.value && user.id == id.value && user.password == password.value){
            alert("Welcome "+user.fname+" "+user.lname+". You have selected to: "+ dropdown.value)
            verified =  true
            return 
        }
    })

    return verified
}

submit.onclick = () => {
    if(!validate())
        return false
    if(!verify()){
        alert("No account found")
        return false
    }
}