const swapImg = (elem) => {
    let front = document.getElementsByClassName("gallery__item--1")[0] 
    
    if(front==elem){
        window.open(elem.classList[0])
    } else {
        front.classList.remove('gallery__item--1')
        elem.classList.add('gallery__item--1')
        elem.parentNode.insertBefore(elem, elem.parentNode.firstChild)
    }
}

const redirect = () => {
    window.open('https://rpzoo.com/contact/')
}

console.log('HELLo')