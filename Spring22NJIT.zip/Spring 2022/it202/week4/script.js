const ucid = document.getElementById('ucid')
const ucids = ['bsm2', 'pojk91', 'klp230', 'po']
const validate = () => {
    if(ucid.value.match(/[a-zA-Z]+[0-9]{0,3}/) == ucid.value){
        if(ucids.includes(ucid.value)){
            return alert('VALID UCID FORMAT AND UCID FOUND')
        }
        return alert('VALID UCID FORMAT BUT INVALID UCID')
    }
    return alert('UCID DOES NOT CONFORM TO VALID FORMAT')
}
