<?php 
$q = $_REQUEST["q"];

//AUTHOR ARRAY
$authors[] = "William Shakespear";
$authors[] = "J.R.R Tolkien";
$authors[] = "Stephen King";
$authors[] = "Ernest Hemingway";
$authors[] = "Charles Dickens";
$authors[] = "F.Scott Fitzgerald";
$authors[] = "J.K. Rowling";
$authors[] = "Eircho Oda";
$authors[] = "Arthur Conan Doyle";
$authors[] = "Agatha Christie";

$guess = "";
if($q != ""){
    $q = strtolower($q);
    foreach($authors as $author){
        if(stristr($q, substr($author, 0, strlen($q)))){
            if($guess == ""){
                $guess = "FOUND: $author";
            }else{
                $guess .= ", $author";
            }
        }
    }
}

if($guess == ""){
    echo "FOUND: Author Not Found";
}
else{
    echo $guess;
}
?>