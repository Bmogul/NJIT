<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>using echo</title>
</head>
<body>
    <p>Standar HTML doc</p>
    <?php
        echo 'Hello, world!';
        echo '<p>Hello, <strong>world!</strong></p>';
    ?>
</body>
</html>