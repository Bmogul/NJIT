<?php

$x = 3.14;
$x = round($x); # 3

echo $x;

$x = 3.142592;
$x = round($x, 3); # 3.142

echo $x;

$x = 20943;
$x = number_format($x); # 20,943

echo $x;

$x = 20943;
$x = number_format($x, 2); # 20,943.00

echo $x;


?>