<?php

#Creating variables
$firstname = 'Burhanuddin';
$lastname = "Mogul";
$book = 'Nope not yet';
$fullname = $firstname . $lastname;

#Printing variables
echo "<p>The book <em>$book</em>
was written by $firstname $lastname</p>";

?>