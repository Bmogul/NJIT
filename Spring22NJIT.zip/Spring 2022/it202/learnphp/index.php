<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <?php

    include('variables.php');
    include('strings.php');
    include('numbers.php');

    ?>
</body>
</html>