<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <?php
    
    # Script - comments.php
    # Created March 22 2022
    # Create by Burhanuddin Mogul
    # This script does nothing much

    echo '<p>This is a line of text. <br /> This is another line of text.</p>';
    echo '<p>Now I\'m done.</p>'; // end

    ?>
</body>
</html>