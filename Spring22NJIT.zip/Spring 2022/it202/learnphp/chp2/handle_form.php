<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Feedback</title>
</head>
<body>
    <?php
    $name =$_REQUEST['name'];
    $email = $_REQUEST['email'];
    $comments = $_REQUEST['comments'];

    echo "<p>Thank you, $name, for the following comments:</p>
    <pre>$comments</pre>
    <p>We will reply to you at $email</p>\n";
    ?>
</body>
</html>