<?php
    # predefined variables
    $file = $_SERVER['SCRIPT_FILENAME'];
    $user = $_SERVER['HTTP_USER_AGENT'];
    $server = $_SERVER['SERVER_SOFTWARE'];

    # print name of script
    echo "<p>You are running the file:<br />$file</p>\n";
    # print users info
    echo "<p>You are viewing this page using:<br />$user</p>\n";
    # print servers info
    echo "<p>This server is runnning:<br />$server</p>\n";
?>