<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css" />
    <title>OrderDB</title>
</head>
<body>
    <form class="heading" action="index.html" method="post">
        <h2>Lushet Lawns and Landscaping</h2>
        <input type="submit" value="Home" class="home">
    </form>
    <table>
    <tr>
        <td>Product Type</td>
        <td>Shipping Address</td>
        <td>Order Number</td>
        <td>Landscaper ID</td>
        <td>Client ID</td>
        <td>Service ID</td>
    </tr>
<?php
include("connect.php");
$query = mysqli_query( $con,"SELECT * from orders");
# $i=0;
while($row=mysqli_fetch_array($query)){
?>
    <tr>
        <td><?php echo $row["type"]; ?></td>
        <td><?php echo $row["address"]; ?></td>
        <td><?php echo $row["orderNum"]; ?></td>
        <td><?php echo $row["landscaperID"]; ?></td>
        <td><?php echo $row["clientID"]; ?></td>
        <td><?php echo $row["serviceID"]; ?></td>
    </tr>
<?php
}
?>
    </table>


</body>
</html>