<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css" />
    <title>AppointmentDB</title>
</head>
<body>
    <form class="heading" action="index.html" method="post">
        <h2>Lushet Lawns and Landscaping</h2>
        <input type="submit" value="Home" class="home">
    </form>
    <table>
    <tr>
        <td>Service Type</td>
        <td>Date of Service</td>
        <td>landscaperID</td>
        <td>Client ID</td>
        <td>Service ID</td>
    </tr>
<?php
include("connect.php");
$query = mysqli_query( $con,"SELECT * from appointments");
# $i=0;
while($row=mysqli_fetch_array($query)){
?>
    <tr>
        <td><?php echo $row["type"]; ?></td>
        <td><?php echo $row["dateofservice"]; ?></td>
        <td><?php echo $row["landscaperID"]; ?></td>
        <td><?php echo $row["clientID"]; ?></td>
        <td><?php echo $row["serviceID"]; ?></td>
    </tr>
<?php
}
?>
    </table>


</body>
</html>