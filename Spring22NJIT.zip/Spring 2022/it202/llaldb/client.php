<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css" />
    <title>ClientDB</title>
</head>
<body>
    <form class="heading" action="index.html" method="post">
        <h2>Lushet Lawns and Landscaping</h2>
        <input type="submit" value="Home" class="home">
    </form>
    <table>
    <tr>
        <td>First Name</td>
        <td>Last Name</td>
        <td>Client ID</td>
    </tr>
<?php
include("connect.php");
$query = mysqli_query( $con,"SELECT * from clients");
# $i=0;
while($row=mysqli_fetch_array($query)){
?>
    <tr>
        <td><?php echo $row["firstname"]; ?></td>
        <td><?php echo $row["lastname"]; ?></td>
        <td><?php echo $row["clientID"]; ?></td>
    </tr>
<?php
}
?>
    </table>


</body>
</html>