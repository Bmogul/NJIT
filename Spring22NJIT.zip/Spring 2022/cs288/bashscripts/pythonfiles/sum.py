

print("SUM")
print(5**5+8**8)
