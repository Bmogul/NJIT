#!/bin/bash

find_py() {

	cd $1
	find . -type d | echo `pwd`
	pwd

}

find_py $1
