#!/bin/sh

lowercaseElDigitOne='^l1$'
onlyDigits='^[0-9]+$'
notAlphanumeric='^[^a-zA-Z0-9]$'
notAtStartCapital='^[^A].*A'
emptyLines='^[ ]*$'
theTime='^([01][0-9]|2[0-3]):[0-5][0-9]$'
ppOre='.*p.*p.*ore'
threeSets='.*(\w)\1.*(\w)\2.*(\w)\3'
zipCode='^([0-9]{5}|[0-9]{5}-[0-9]{4})$'
anInteger='^(([01]?[0-9]?[0-9])|(20[0-9])|(21[01]))$'
romanNumeral='^[IVX]{1,6}$'
