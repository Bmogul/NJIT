#include <stdio.h>

typedef enum 
{
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAy = 8
}Day;

int main()
{

    Day today = MONDAY;

    return 0;
}