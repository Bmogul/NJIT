#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *copy_string(char *s){
    char *copy = NULL;
    if(s != NULL){
        copy = (char *)malloc(strlen(s)+1);
        if(copy != NULL)
            strcpy(copy, s);
    }
    return copy;
}

int main()
{
    char *name = "Burhanuddin";
    printf("%lu\n", sizeof(name));
    char *clone = copy_string(name);
    printf("%s\n", clone);

    free(name);
    free(clone);œ
    return 0;
}