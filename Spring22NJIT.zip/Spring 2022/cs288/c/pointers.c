#include <stdio.h>

int main()
{

    int *p = 7;

    return 0;
}