#include <stdio.h>

int main()
{
    // memory = an array of bytes within RAM
    // memory block = a single unit (byte) within memory, used to hold some value
    // memory address = the address of where a memory block is located

    char a;
    long b[4];

    printf("%d bytes\n", (int)sizeof(a));
    printf("%d bytes\n", (int)sizeof(b));

    printf("%p \n", &a);
    printf("%p \n", &b);

    return 0;
}