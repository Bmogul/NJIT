#include <stdio.h>

int main()
{

    // FILE *pF = fopen("test.txt", "a");

    // fprintf(pF, "\nBurhanuddin Mogul");
    
    // fclose(pF);

    if(remove("test.txt") == 0)
    {
        printf("Removed file \n");
    }
    else{
        printf("Not deleted\n");
    }

    return 0;
}