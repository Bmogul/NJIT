#include <stdio.h>

void printAge(int *age);


int main()
{
    // pointer = a variable like reference that holds a memory address to anotehr variable array etc
    //          some tasks are performed better with poitners
    //          * = indirection operator (value at address)
    // pointer advantages:
    //  less time in program execution
    //  working on origianl variable
    //  with help of pointers create data structers (linked list, stack, queue)
    //  searching and sorting large data esilt
    //  dynamilcally memory allocation

    int age = 19;
    int *pAge = &age;

    printf("address of age: %p\n", &age);
    printf("address of pAge: %p\n", &pAge);

    printf("value of pAge: %p\n", pAge);

    printf("value of age: %d\n", age);
    printf("vale at stored address: %d\n", *pAge); //derefernece

    printAge(pAge);
    printf("%d\n", age);

    return 0;
}

void printAge(int *age)
{
    *age = 10;
    printf("You are %d years old\n", *age);
}