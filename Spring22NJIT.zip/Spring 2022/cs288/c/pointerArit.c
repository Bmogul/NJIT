#include <stdlib.h>

short n;
short *p;

/*
sizeof n == sizeof short == sizeof *p
sizeof p == sizeof short* == sizeof &n
*/

int main()
{
    short v[] = {1,2,3};
    short *p = &v[0];

    p = &v[1];

    /*
    v[0] ---> 0x00 ---> 0x00000800=
    --------> 0x01
    v[1] ---> 0x00 ---> 0x00000802
    --------> 0x02 
    v[2] ---> 0x00 ---> 0x00000804
    --------> 0x03
    p ------> 0x00 ---> 0x00000806
    --------> 0x00
    --------> 0x08
    --------> 0x00
    */

    return 0;
}
