#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void selectionSort(int *array, int size){
	int i, j, min, temp;
	for(i = 0; i < size; i++){
		min = i;
		for(j = i; j < size; j++){
			if (*(array+j) < *(array+min))
				min = j;
		}
		
		temp = *(array+min);
		*(array+min) = *(array+i);
		*(array+i) = temp;
	}
}
void merge(int arr[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
  
    int *L=(int*)malloc(sizeof(int)*n1), *R=(int*)malloc(sizeof(int)*n2);
  
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];
  
    i = 0; 
	j = 0; 
    k = l; 
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        }
        else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
  

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
  

    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}
  
void mergeSort(int arr[], int l, int r)
{
    if (l < r) {

        int m = l + (r - l) / 2;
  
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
  
        merge(arr, l, m, r);
    }
}

int getMax(int *arr, int size){
	int max = *arr;
	int i;
	for (i = 1; i < size; i++)
		if(*(arr+i) > max)
			max = *(arr+i);
	return max;
}

void countSort(int *arr, int size, int exp){

	int *output = (int *)malloc(sizeof(int)*size);
	int i, *count = (int*)malloc(sizeof(int)*10);

	for(i = 0; i < size; i++)
		count[(arr[i]/exp)%10]++;

	for(i = 1; i < 10; i++)
		*(count+i) += *(count+i-1);

	for(i=size-1; i >= 0; i--){
		output[count[(arr[i]/exp)%10]-1] = arr[i];
		count[(arr[i]/exp)%10]--;
	}

	for(i=0; i < size; i++)
		arr[i] = output[i];

}

void RadixSort(int *arr, int size){

	int m = getMax(arr, size);
	int exp;
	for(exp = 1; m / exp > 0; exp *= 10)
		countSort(arr, size, exp);

}

void PrintArray(int *arr, int size){
	int i;
	for(i=0; i < size; i++)
			printf("%d, ", *(arr+i));
	printf("\n");
}

int main(){
/*
 * Will be timing different sorting algorithms
 * to see which is the most efficent
 */
	int size = 1000000;
	int *arr1 = (int *)malloc(sizeof(int)*size);
	int *arr2 = (int *)malloc(sizeof(int)*size);
	int *arr3 = (int *)malloc(sizeof(int)*size);

	int i;
	double end;
	clock_t t;
	for(i=0; i<size; i++){
		*(arr1+i) = rand()%1000;
		*(arr2+i) = rand()%1000;
		*(arr3+i) = rand()%1000;
	}

	t = clock();
	selectionSort(arr1, size);
	t = clock() - t;
	end = ((double)(t)/CLOCKS_PER_SEC)  * 1000;
	printf("Selection: %f\n", end);


	// t = clock();
	// mergeSort(arr2,0, size-1);
	// t = clock()-1;
	// end = ((double)(t)/CLOCKS_PER_SEC)  * 1000;
	// printf("Merge: %f\n", end);

	// t = clock();
	// RadixSort(arr3, size);
	// t = clock() - t;
	// end = ((double)(t)/CLOCKS_PER_SEC)  * 1000;
	// printf("Radix: %f\n", end);

	return 0;
}
