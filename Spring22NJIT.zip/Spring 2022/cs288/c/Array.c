#include <stdio.h>
#include <string.h>

int main()
{

    double prices[] = {5.0, 10.0, 15.0, 25.0, 20.0};
    char name[] = "Bro";
    strcpy(name, "Burhanuddin");

    return 0;
}