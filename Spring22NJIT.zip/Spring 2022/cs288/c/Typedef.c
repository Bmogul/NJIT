#include <stdio.h>
#include <string.h>

typedef struct
{
    char name[25];
    char passsword[12];
    int id;
}User;


int main()
{

    // typedef = reserved keyword that gives an exisiting datatype a "nickname"

    User userOne = {"Burhanuddin", "psswd", 30440549};

    return 0;

}