import xml.dom.minidom
import sys
import mysql.connector
from datetime import date
import datetime

forecast = {};
weekdays = ['sunday','monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
locations = {'Camden.xhtml':'Camden', 'Hoboken.xhtml':'Hoboken', 'NB.xhtml':'New Brunswick', 'Newark.xhtml':'Newark', 'Trenton.xhtml':'Trenton'};

mydb = mysql.connector.connect(
    host='localhost',
    user='snow',
    password='P@$swd123',
    database='weather'
)
cursor = mydb.cursor()

sql = "drop table if exists sevendayforecast;"
cursor.execute(sql)

sql = """
CREATE table sevendayforecast(
    day varchar(100) not null,
    forecast varchar(500) not null,
    ordernum varchar(3) not null,
    shortdesc varchar(100),
    temp varchar(25),
    city varchar(50) not null,
    date varchar(100) not null
);
"""
cursor.execute(sql)

for currentfile in locations.keys():
    domtree = xml.dom.minidom.parse(currentfile);
    group = domtree.documentElement;
    thedate = date.today()

    uls = group.getElementsByTagName('ul')
    for ul in uls:
        if ul.hasAttribute('id') and ul.getAttribute('id') == 'seven-day-forecast-list':
            lis = ul.getElementsByTagName('li');
            num = 0;
            for li in lis:
                if li.getAttribute('class') == 'forecast-tombstone':
                    ps = li.getElementsByTagName('p');
                    day = "";
                    shortdesc = "";
                    temp = "";
                    for node in ps[0].childNodes:
                        if node.nodeType == node.TEXT_NODE:
                            day = day + " " + node.data
                    day = day.strip().lower()
                    for node in ps[2].childNodes:
                        if node.nodeType == node.TEXT_NODE:
                            shortdesc = shortdesc + " " + node.data
                    for node in ps[3].childNodes:
                        if node.nodeType == node.TEXT_NODE:
                            temp = temp + " " + node.data
                    if (not (day.split()[0]  in weekdays)) and day != 'tonight':
                        day = 'today' 
                    forecast[day] = {'short-desc':shortdesc, 'temp':temp};
                    num = num+1;
            break;
    sameday = 0;
    divs = group.getElementsByTagName('div')
    for div in divs:
        if div.hasAttribute('id') and div.getAttribute('id') == 'detailed-forecast-body':
            order = 0;
            for node in div.childNodes:
                if node.childNodes.length > 0:
                    subNode = node.childNodes[1];
                    day = node.childNodes[0].childNodes[0].toxml().strip("</b>").lower()
                    if (not (day.split()[0] in weekdays)) and day != 'tonight':
                        day = 'today'
                    if day == 'today':
                        sameday = 0
                    elif day =='tonight':
                        sameday = 1
                    if day in forecast.keys():
                        forecast[day]['forecast'] = subNode.childNodes[0].data
                        forecast[day]['order'] = order;
                        forecast[day]['location'] = locations[currentfile];
                        forecast[day]['date'] = thedate.strftime("%m/%d/%Y");
                    else:
                        forecast[day] = {'forecast': subNode.childNodes[0].data, 'order':order, 'location':locations[currentfile], 'date':thedate.strftime("%m/%d/%Y")}
                    order = order+1;
                    if sameday%2 != 0:
                        thedate = thedate + datetime.timedelta(days=1)
                    sameday += 1
            break


    for key in forecast.keys():
        if 'short-desc' in forecast[key].keys():
            sql = """
            INSERT INTO sevendayforecast (day, forecast, ordernum, shortdesc, temp, city, date) VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            val = (key, forecast[key]['forecast'], forecast[key]['order'], forecast[key]['short-desc'], forecast[key]['temp'], locations[currentfile], forecast[key]['date'])
        else:
            sql = """
            INSERT INTO sevendayforecast (day, forecast, ordernum, city, date) VALUES (%s, %s, %s, %s, %s)
            """
            val = (key, forecast[key]['forecast'], forecast[key]['order'], locations[currentfile], forecast[key]['date'])
        # print(sql, val)
        cursor.execute(sql, val)
    mydb.commit()

