<?php 
include('sqlconnect.php');
$dcity = $_GET['dcity'];
if (isset($_SERVER['REMOTE_ADDR'])){
    $ip = $_SERVER['REMOTE_ADDR'];
    $query = "SELECT * FROM userdefaults WHERE ip='$ip';";
    $result = mysqli_query($con, $query);
    if($result){
        if(mysqli_num_rows($result) > 0){
            $query = "UPDATE userdefaults SET city='$dcity' WHERE ip='$ip';";
            $result = mysqli_query($con, $query);
            if(!$result){
                echo "Error in updating default";
            }
        }else{
            $query = "INSERT INTO userdefaults (ip, city) VALUES ('$ip', '$dcity');";
            $result = mysqli_query($con, $query);
            if(!$result){
                echo "Error in inserting default";
            }
        }
    }
}
?>