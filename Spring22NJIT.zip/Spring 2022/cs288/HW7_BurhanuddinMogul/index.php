<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" />
    <title>Weather App</title>
</head>

<body>
    <?php
    include('sqlconnect.php');
    ?>
    <ul class="nav">
        <li class="home"><a href="./index.php">Home</a></li>
        <li class="location"><a href="?loca=Camden">Camden</a></li>
        <li class="location"><a href="?loca=Hoboken">Hoboken</a></li>
        <li class="location"><a href="?loca=Newark">Newark</a></li>
        <li class="location"><a href="?loca=New+Brunswick">New Brunswick</a></li>
        <li class="location"><a href="?loca=Trenton">Trenton</a></li>
        <li class="location"><a href="#def">Set Default</a></li>
    </ul>
    <h1 class="title">Weather</h1>
    <?php 
    $loc = "Newark";
    $ip = $_SERVER['REMOTE_ADDR'];
    $query = "SELECT city FROM userdefaults WHERE ip='$ip';";
    $result = mysqli_query($con, $query);
    if (isset($_GET['loca'])) {
        $loc = $_GET['loca'];

    } else if ($result && mysqli_num_rows($result) > 0) {
        $loc = mysqli_fetch_array($result)["city"];
    } else {
        $loc = "Camden";
    }
    echo "<h2 id='place' class='title' >$loc</h2>\n";
    ?>
    <div class="today">
        <?php
        
        $query = mysqli_query($con, "SELECT * from sevendayforecast WHERE city='$loc';");
        echo "<div class='block' >\n";
        while ($row = mysqli_fetch_array($query)) {
            if ($row['day'] == 'today' || $row['day'] == 'tonight') {
                $day = ucFirst($row['day']);
                $desc = $row['shortdesc'];
                $temp = $row['temp'];
                $date = $row['date'];
                echo "<ul class='day'>\n";
                echo "<li><label>$day - $date</label></li>\n";
                echo "<li><p>$desc<br />\n<strong>$temp</strong></p>\n</li>\n";
                // echo "<li>$temp</li>\n";
                echo "</ul>\n";
            }
        }
        echo "</div>\n";
        ?>
    </div>
    <div class="forecast">
    <h2 class="title">Detailed Forecast</h2>
        <?php
        $query = mysqli_query($con, "SELECT * from sevendayforecast WHERE city='$loc';");
        $stylenum = 0;
        while ($row = mysqli_fetch_array($query)) {
            $style = 'fcast';
            if ($stylenum % 2 != 0)
                $style = 'fcast2';
            echo "<div class='$style' >\n";
            $day = ucFirst($row['day']);
            $desc = $row['forecast'];
            $shortd = $row['shortdesc'];
            $temp = $row['temp'];
            $date = $row['date'];
            echo "<ul class='day'>\n";
            echo "<li><label>$day - $date</label></li>\n";
            echo "<li><p>
            <strong>Description: </strong>$shortd<br />\n
            <strong>Detailed: </strong>$desc<br />\n
            <strong>Temp: </strong>$temp
            </p>\n</li>\n";
            echo "</ul>\n";
            echo "</div>\n";
            $stylenum++;
        }
        ?>
    </div>

    <div id='def' class='customize'>
        <form   id='defaults'>
            <label>Select default location</label>
            <select id='defaultCity'>
                <option value="Camden">Camden</option>
                <option value="Hoboken">Hoboken</option>
                <option value="Newark">Newark</option>
                <option value="New Brunswick">New Brunswick</option>
                <option value="Trenton">Trenton</option>
            </select>
            <input type="button" id='submit' value="Enter">
        </form>
    </div  >
    <script>
        document.getElementById('submit').addEventListener('click', () => {
            const dcity = document.getElementById('defaultCity').value;
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'update.php?dcity=' + dcity, true);
            xhr.onload = function() {
                if (this.responseText != "")
                    alert(this.responseText)
            }
            xhr.send()
        })
    </script>

</body>

</html>