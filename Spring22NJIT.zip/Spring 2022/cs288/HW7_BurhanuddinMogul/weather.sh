#!/bin/bash

links=("http://forecast.weather.gov/MapClick.php?CityName=Newark&state=NJ" "http://forecast.weather.gov/MapClick.php?CityName=Trenton&state=NJ" "http://forecast.weather.gov/MapClick.php?CityName=Camden&state=NJ" "http://forecast.weather.gov/MapClick.php?CityName=Hoboken&state=NJ" "http://forecast.weather.gov/MapClick.php?CityName=New+Brunswick&state=NJ")
locations=(Newark Trenton Camden Hoboken NB)



while true; do
    if [ ! -f "tagsoup-1.2.1.jar" ]; then
        wget https://repo1.maven.org/maven2/org/ccil/cowan/tagsoup/tagsoup/1.2.1/tagsoup-1.2.1.jar -qO tagsoup-1.2.1.jar
    fi
    for i in ${!links[@]}; do
        wget ${links[$i]} -qO "${locations[$i]}.html" 
        java -jar tagsoup-1.2.1.jar --files ${locations[$i]}.html
        rm *.html
    done
    python3 parser.py && rm *.xhtml
    echo "DONE...waiting to update"
    sleep 21600
done