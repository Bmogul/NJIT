<?php 
    $con = mysqli_connect("localhost", "snow", 'P@$swd123', 'weather');
    ?>