#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(){

    char **values;
    int *q;
    values = (char**)malloc(5 * (int)sizeof(char*));
    values[0] = "sd";
    values[1] = "sd";
    values[2] = "sd";
    values[3] = "sd";
    values[4] = NULL;
    values[5] = "sd";
    int size = 0;

    

    //     int *p,*q;
    // p=(int *)malloc(3*sizeof(int));
    // p[0]=1;
    // p[1]=2;
    // p[2]=3;
    q=(int *)malloc(5*sizeof(int));
    q[0]=1;
    q[1]=2;
    q[2]=3;
    for(int i = 0; i < 5; i++){
        size++;
        printf("%s\n", values[i]);
    }
    // free(p);
    // p=q;
    // q=NULL;
    // printf("%d",p[2]);

    

    printf("Size of values: %d\n", (int)(sizeof(*q)/ sizeof(int)));
    
     

    return 0;
}