#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Node{
    char *key;
    char **values;
    struct Node *next;
};

struct Map{
    struct Node *head;
};

struct Map MAP_new(){
    /* construct an empty list */
    struct Map map;
    map.head = NULL;
    return map;
}

int MAP_empty(struct Map *map){
    /* return true if the list contains no keys */
    return map->head == NULL;
}

int MAP_length(struct Map *map){
    /* return the number of keys in the list */
    struct Node *node;

    int i = 0;
    for (node = map->head; node != NULL; node = node->next){
        i++;
    }
    return i;
}

int MAP_contains(struct Map *map, char *key){
    /* return true if the list contains the key */
    struct Node *node;

    int i = 0;
    for (node = map->head; node != NULL; node = node->next){
        if (!strcmp(node->key,key))
            return 1;
        i++;
    }
    return 0;
}

void MAP_clear(struct Map *map){
     /*remove all associations from the list */
     struct Node *current = map->head;
     struct Node *next;
     while(current != NULL){
         char *val = current->values[0];
         int i = 0;
         while(val != NULL){
             free(val);
             val = current->values[++i];
         }
         free(current->values);
         free(current->key);
         next = current->next;
         free(current);
         current = next;
     }
     map->head = NULL;
     
}

void MAP_add(struct Map *map, char *key, char *value){
    /* add an association from the given key to the given value */
    struct Node *node = NULL;
    struct Node *temp = NULL;
    int i = 0;
    for (node = map->head; node != NULL; node = node->next){
        char **newValues, *tempWord;
        int len = 0;
        if(!strcmp(node->key, key)){
            while((tempWord = node->values[len++])!=NULL){
                if(!strcmp(tempWord, value))
                    return;
            }
            newValues = malloc((len+1)*sizeof(char *));
            for(i = 0; i < len; i++)
                newValues[i] = node->values[i];
            newValues[len-1] = strdup(value);
            free(node->values);
            node->values = newValues;
            newValues = NULL;
            return;
        }
    }
    node = malloc(sizeof(struct Node));
    node->key = strdup(key);
    node->values = malloc(2*sizeof(char*));
    node->values[0] = strdup(value); node->values[1] = NULL;
    node->next = NULL;

    if(map->head == NULL)
        map->head = node;
    else{
        for(temp = map->head; temp->next != NULL; temp = temp->next);
        temp->next = node;
    }

}

char **MAP_find(struct Map *map, char *key){
    /* return the values associated with the given key */
    struct Node *node;

    int i = 0;
    for (node = map->head; node != NULL; node = node->next)
    {
        if (!strcmp(node->key,key))
            return node->values;
        i++;
    }
    return NULL;
}

int comparator(const void *p1, const void *p2){
    return memcmp(p1, p2, 1);
}

int main(int argc, char *argv[]){
    /* anagram application */
    char *value = NULL;
    char *input = malloc(46);
    FILE *file = NULL;
    struct Map map;
    struct Node *node = NULL;
    int maxLen = 0, added = 0;

    maxLen = argc == 3 ? atoi(argv[2]) : 45;

    file = fopen(argv[1], "r");
    value = malloc(45);
    map = MAP_new();

    if (file == NULL){
        printf("file cannot be opened \n");
        return 1;
    }
    while(fscanf(file, "%s", value) == 1){
        if((int)strlen(value) <= maxLen && (int)strlen(value) >= 2){
            char *key = malloc(45);
            strcpy(key, value);
            qsort(key, strlen(key), 1, comparator);
            MAP_add(&map, key, value);
            free(key);
        }        
    }
    free(value);
    added = 0;
    for(node = map.head; node!=NULL; node = node->next){
        int i = 0;
        while(node->values[i] != NULL){
            i++;
        }
        added += i;
    }
    printf("Number of words added (2 <= length <= %d): %d\n", maxLen, added);
    printf("Number of nodes in the data structure: %d\n", MAP_length(&map));

    while(strcmp(input, "q") || strcmp(input, "Q")){
        char **valueList = NULL;
        int i = 0;
        printf("String to search, \'Q\' to quit.\n? ");
        fgets(input, 46, stdin);
        input[strlen(input)-1] = '\0';
        if(!strcmp(input, "q") || !strcmp(input, "Q")){
            printf("Good bye!\n");
            break;
        }
        if((int)strlen(input) < 2  || (int)strlen(input) > maxLen){
            printf("The word must be between 2 and %d characters.\n", maxLen);
            continue;
        }
        qsort(input, strlen(input), 1, comparator);
        if(MAP_contains(&map, input)){
            printf("Words that match:\n");
            valueList = MAP_find(&map, input);
            while(valueList[i] != NULL){
                printf("%s\n",valueList[i++]);
            }
        }else{
            printf("No match!\n");
        }
    }

    MAP_clear(&map);
    free(input);
    fclose(file);
    return 0;
}