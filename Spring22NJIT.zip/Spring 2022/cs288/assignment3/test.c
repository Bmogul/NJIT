#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Node{
    char *key;
    char **values;
    struct Node *next;
};

struct Map{
    struct Node *head;
};

int comparator(const void *p1, const void *p2){
    return memcmp(p1, p2, 1);
}

struct Map MAP_new(){
    /* construct an empty list */
    struct Map map;
    map.head = NULL;
    return map;
}

int MAP_empty(struct Map *map){
    /* return true if the list contains no keys */
    return map->head == NULL;
}

int MAP_length(struct Map *map){
    /* return the number of keys in the list */
    struct Node *node;

    int i = 0;
    for (node = map->head; node != NULL; node = node->next){
        i++;
    }
    return i;
}

void MAP_add(struct Map *map, char *key, char *value){

}

int MAP_contains(struct Map *map, char *key){
    return 1;
}

char **MAP_find(struct Map *map, char *key){
    char *h[] = NULL;
    return h;
}

int main(int argc, char *argv[]){
    /* anagram application */
    char *value;
    char *input = malloc(46);
    FILE *file;
    struct Map map;
    struct Node *node = NULL;
    int maxLen, added;

    maxLen = argc == 3 ? atoi(argv[2]) : 45;

    file = fopen(argv[1], "r");
    value = malloc(45);
    map = MAP_new();

    if (file == NULL){
        printf("file cannot be opened \n");
        return 1;
    }
    while(fscanf(file, "%s", value) == 1){
        if((int)strlen(value) <= maxLen && (int)strlen(value) >= 2){
            char *key = malloc(45);
            strcpy(key, value);
            qsort(key, strlen(key), 1, comparator);
            MAP_add(&map, key, value);
            free(key);
        }        
    }
    free(value);
    added = 0;
    for(node = map.head; node!=NULL; node = node->next){
        int i = 0;
        while(node->values[i] != NULL){
            i++;
        }
        added += i;
    }
    printf("Number of words added (2 <= length <= %d): %d\n", maxLen, added);
    printf("Number of nodes in the data structure: %d\n", MAP_length(&map));

    while(strcmp(input, "q") || strcmp(input, "Q")){
        char **valueList = NULL;
        int i = 0;
        printf("String to search, \'Q\' to quit.\n? ");
        fgets(input, 46, stdin);
        input[strlen(input)-1] = '\0';
        if(!strcmp(input, "q") || !strcmp(input, "Q")){
            printf("Good bye!\n");
            break;
        }
        if((int)strlen(input) < 2  || (int)strlen(input) > maxLen){
            printf("The word must be between 2 and %d characters.\n", maxLen);
            continue;
        }
        qsort(input, strlen(input), 1, comparator);
        if(MAP_contains(&map, input)){
            printf("Words that match:\n");
            valueList = MAP_find(&map, input);
            while(valueList[i] != NULL){
                printf("%s\n",valueList[i++]);
            }
        }else{
            printf("No match!\n");
        }
    }

    MAP_clear(&map);
    free(input);
    fclose(file);
    return 0;
}