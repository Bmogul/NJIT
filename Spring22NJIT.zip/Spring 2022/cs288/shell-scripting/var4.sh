#!/bin/sh

# unlimited parameters

while [ "$#" -gt "0" ] 
do
	echo "\$1 is $1"
	shift
done

# $? returns exit value of the lsat run command
/usr/local/bin/my-command
if [ "$?" -ne "0" ]; then
	echo "Sorry, we had a problem there!"
fi
