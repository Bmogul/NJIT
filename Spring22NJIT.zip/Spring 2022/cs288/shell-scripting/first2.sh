#!/bin/sh

echo "Hello    World"
echo "Hello World"
echo "Hello * World"
echo Hello * World
echo Hello     World
echo "Hello" World
echo Hello "    " World
echo "Hello" "*" "World"
echo `hello` world
echo 'hello' world
