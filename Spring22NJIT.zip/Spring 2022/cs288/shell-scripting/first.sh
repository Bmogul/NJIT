#!/bin/sh
# Thus us a comment!
# Note the assigment operator cannot have spaces around it
MY_MESSAGE="HELLO WORLD"
echo $MY_MESSAGE 	# THis is also a comment
