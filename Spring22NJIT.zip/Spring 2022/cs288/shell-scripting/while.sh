#!/bin/sh

INPUT_STRING=hello
while [ "$INPUT_STRING" != "bye" ]
do
	echo "Please type something in (bye to quit)"
	read INPUT_STRING
	echo "You typed: $INPUT_STRING"
done

echo "\n\n"

#while :
#do
#	echo "Please type something in (^C to quit)"
#	read INPUT_STRING_TWO
#	echo "You typed: $INPUT_STRING_TWO"
#done

echo "\n\n"

while read input_text
do
	case $input_text in
		hello)		echo English ;;
		howdy)		echo American ;;
		gday)		echo Australian ;;
		bonjour)	echo French ;;
		"guten tag")	echo German ;;
		*)		echo Unknown Language: $input_text ;;
	esac
done < myfile.txt

