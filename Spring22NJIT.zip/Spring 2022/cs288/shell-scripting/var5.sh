#!/bin/sh

# $$ is PID (process IDentifier) of currently running shell
# useful for creating temp files such as /tmp/my-script.$$ 
# which is useful if many instance of teh script could be run at the same time
# and they all need their own temp files

# $! is the PID of ht elast trun background process. useful to keep track of the
#  process as it gets on with its job

# IFS, Internal Field Seperator. default valus is SPACE TAB NEWLINE
# but if you change it it's easier to take a copy

old_IFS="$IFS"
IFS=:
echo "Please input some data sepreates by colons:"
read x y z
IFS=$old_IFS
echo "x is $x y is $y z is $z"

# defualt values
echo --en "waht is your name [ `whoami` ] "
read myname
echo "Your name is : ${myname:-`whoami`}"
echo "Your name is : ${myname:=Burhanuddin Mogul}"

# :- temp default value
# := assigns default val to var
