#!/bin/sh

if [ "$x" -lt "0" ]; then
	echo "x is less than Zero"
fi
if [ "$x" -gt "0" ]; then
	echo "x is more than Zero"
fi

[ "$x" -le "0" ] && \
	echo "x is less than or equal to zero"
[ "$x" -ge "0" ] && \
        echo "x is greater than or equal to zero"
[ "$x" = "0" ] && \
        echo "x is the string or number \"0\""
[ "$x" = "hello"ø ] && \
        echo "x matches the string \"hello\""
[ "$x" != "hello" ] && \
	echo "x is not the string \"hello\""
[ -n "$x" ] && \
	echo "x is of nonzero length"
[ -f "$x" ] && \
	echo "x is the path of a real file" || \
	echo "No such file: $x"
[ -x "$x" ] && \
	echo "x is the path of an executable file"
[ "$x" -nt "/etc/passwd" ] && \
	echo "x is a file which is newer than /etc/passwd"
