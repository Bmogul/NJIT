#!/bin/sh
echo "What is your name?"
read USER_NAME
echo "Hello $USER_NAME"
echo "A file named ${USER_NAME}_file hs been created"
touch "${USER_NAME}_file"
