#!/bin/sh
echo "MYVAR os: $MYVAR"
MYVAR="hi there"
echo "MYVAR is $MYVAR"
