#!/bin/sh

echo What is your name?
read MY_NAME
echo "Hello $MY_NAME - hope you're well."
