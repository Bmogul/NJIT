#!/bin/sh

if [ : ] #condition 
then
	# if code
	echo "True"
else
	# else code
	echo "False"
fi

if [ : ]; then
	#if code
	echo Hello
fi

if [ : ]; then
	echo "Something"
	elif [ : ]; then
		echo "Something else"
	else
		echo "None of the above"
fi

# simpler if else format
	[ : ] && echo "True" || echo "False"
