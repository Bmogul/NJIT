#!/bin/sh
for i in 1 2 9 3 0
do
	echo "Looping ... number $i"
done
echo "\n\n"

for i in hello 1 * 2 goodbye
do
	echo "looping ... i is set to $i"
done
