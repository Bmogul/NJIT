import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class MissingCards {
  public static class MissingCardsMapper extends Mapper<Object, Text, Text, NullWritable> {
    private static final Set<String> FULL_DECK = new HashSet<>();
    static {
      String[] suits = { "SPADES", "HEARTS", "DIAMONDS", "CLUBS" };
      String[] ranks = { "ACE", "2", "3", "4", "5", "6", "7", "8", "9", "10", "JACK", "QUEEN", "KING" };
      for (String rank : ranks) {
        for (String suit : suits) {
          FULL_DECK.add(rank + " " + suit);
        }
      }
    }

    private Set<String> foundCards = new HashSet<>();

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      String card = value.toString().trim();
      if (FULL_DECK.contains(card)) {
        foundCards.add(card);
      }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
      Set<String> missingCards = new HashSet<>(FULL_DECK);
      missingCards.removeAll(foundCards);
      for (String missingCard : missingCards) {
        context.write(new Text(missingCard), NullWritable.get());
      }
    }
  }

  public static class MissingCardsReducer extends Reducer<Text, NullWritable, Text, NullWritable> {
    @Override
    protected void reduce(Text key, Iterable<NullWritable> values, Context context)
        throws IOException, InterruptedException {
      context.write(key, NullWritable.get());
    }
  }

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "missing cards");
    job.setJarByClass(MissingCards.class);
    job.setMapperClass(MissingCardsMapper.class);
    job.setReducerClass(MissingCardsReducer.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(NullWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
