#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cctype>
using namespace std;

int main(int argc, char const *argv[])
{
    int numInts = 0;
    string word = "897-909/9034-adflsjfn9090";
    bool isInt = false;
    for (int i = 0; i < word.size(); i++)
    {
        if (isdigit(word[i]))
        {
            cout << word[i] << endl;
            isInt = true;
        }
        else
        {
            if (isInt)
            {
                numInts++;
                isInt = false;
            }
        }
    }

    if (isInt)
        numInts++;

    cout << numInts << endl;
    return 0;
}
