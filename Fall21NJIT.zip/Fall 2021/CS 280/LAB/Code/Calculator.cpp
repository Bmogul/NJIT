#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
    /* code */

    char operators[] = {'+', '-', '*', '/'};
    int ex = 0;
    while (ex != -1)
    {
        int num1, num2;
        char op;
        cout << "Enter First Number: ";
        cin >> num1;
        cout << "Enter operator (+, -, /, *)";
        cin >> op;
        cout << "Enter Second Number: ";
        cin >> num2;

        int result;

        switch (op)
        {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '/':
            result = num1 / num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        default:
            result = 0;
            break;
        }
        cout << result;
        cout << "-1 to exit";
        cin >> ex;
    }

    return 0;
}
