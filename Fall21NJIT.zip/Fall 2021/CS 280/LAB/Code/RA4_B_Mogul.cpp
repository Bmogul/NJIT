#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cctype>
#include <map>
#include <iterator>
#include <algorithm>
#include <regex>
using namespace std;

int main(int argc, char const *argv[])
{

    //checking for file name
    if (argc < 2)
    {
        cout << "No file is found\n";
        return 1; //exit
    }

    string fileName = argv[1];
    ifstream fileToRead;
    fileToRead.open(fileName.c_str());

    //checking to see if file can be opened
    if (!fileToRead)
    {
        cout << "File cannot be opened: " << fileName << endl;
        return 1; //exit
    }

    if (fileToRead.bad())
    {
        cout << "File is empty." << endl;
        return 1;
    }

    //creating the prep map
    map<string, int> PrepCount = {{"after", 0}, {"at", 0}, {"between", 0}, {"by", 0}, {"in", 0}, {"into", 0}, {"on", 0}, {"over", 0}, {"to", 0}, {"with", 0}};
    int numLines = 0;
    int numWords = 0;

    //reading the file
    while (fileToRead.good())
    {
        //reading line
        string currentLine;
        getline(fileToRead, currentLine);
        numLines++;

        if (std::regex_replace(std::regex_replace(currentLine, std::regex("\\s+$"), std::string("")), std::regex("^\\s+"), std::string("")) == "")
        {
            cout << currentLine;
            numWords++;
        }
        std::transform(currentLine.begin(), currentLine.end(), currentLine.begin(),
                       [](unsigned char c)
                       { return std::tolower(c); });
        istringstream inputString(currentLine);
        string currentWord;
        inputString >> currentWord;
        do
        {
            if (PrepCount.count(currentWord) > 0)
            {
                PrepCount[currentWord]++;
            }

        } while (inputString >> currentWord);
    }

    if (numWords == 0)
    {
        cout << "File is empty." << endl;
        return 1; //exit
    }

    //finding most common prep
    map<string, int>::iterator iter;
    int max = 0;
    string mostCommonPrep = "after";
    for (iter = PrepCount.begin(); iter != PrepCount.end(); iter++)
    {
        if (iter->second > max)
        {
            max = iter->second;
            mostCommonPrep = iter->first;
        }
    }

    cout << "List of Prepositions seen in the file and their number of occurrences:" << endl;
    cout << "\nafter: " << PrepCount["after"];
    cout << "\nat: " << PrepCount["at"];
    cout << "\nbetween: " << PrepCount["between"];
    cout << "\nby: " << PrepCount["by"];
    cout << "\nin: " << PrepCount["in"];
    cout << "\ninto: " << PrepCount["into"];
    cout << "\non: " << PrepCount["on"];
    cout << "\nover: " << PrepCount["over"];
    cout << "\nto: " << PrepCount["to"];
    cout << "\nwith: " << PrepCount["with"] << endl;
    cout << "The preposition with maximum occurrences is \"" << mostCommonPrep << "\" found " << max << " times." << endl;

    return 0;
}
