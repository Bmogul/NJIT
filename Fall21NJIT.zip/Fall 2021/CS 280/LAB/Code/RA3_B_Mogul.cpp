#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cctype>
using namespace std;

int main(int argc, char const *argv[])
{
    //checking if there is a file name
    if (argc < 2)
    {
        cout << "No file is found\n";
        return 1; //exit
    }

    string fileName = argv[1];
    ifstream fileToRead;
    fileToRead.open(fileName.c_str());

    //checking to see if file can be opened
    if (!fileToRead)
    {
        cout << "File cannot be opened: " << fileName << endl;
        return 1; //exit
    }

    //variables to keep track of
    int numLines = 0, numChars = 0, numDigits = 0, numAlpha = 0, numPunc = 0, numWords = 0, numInts = 0;
    char current = 'p';
    string building = "";
    //reading contents of the file
    while (fileToRead.get(current))
    {
        numChars++;
        building += current;
        if (current == '\n')
        {
            istringstream ss(building);
            string word;
            while (ss >> word)
            {
                numWords++;
                bool isInt = false;
                for (int i = 0; i < word.size(); i++)
                {
                    if (isdigit(word[i]))
                    {
                        isInt = true;
                    }
                    else
                    {
                        if (isInt)
                        {
                            numInts++;
                            isInt = false;
                        }
                    }
                }
                if (isInt)
                    numInts++;
            }

            building = "";
            numLines++;
        }
        else
        {
            if (ispunct(current))
            {
                numPunc++;
            }
            else
            {
                if (isalnum(current))
                {
                    building += current;
                    if (isalpha(current))
                    {
                        numAlpha++;
                    }
                    if (isdigit(current))
                    {
                        numDigits++;
                    }
                }
            }
        }
    }

    //after checking file, if it is empty
    if (numLines == 0)
    {
        cout << "File is empty." << endl;
        return 1; //exit
    }

    cout << "LINES: " << numLines << endl;
    cout << "CHARS: " << numChars << endl;
    cout << "DIGITS: " << numDigits << endl;
    cout << "LETTERS: " << numAlpha << endl;
    cout << "PUNCTUATIONS: " << numPunc << endl;
    cout << "WORDS: " << numWords << endl;
    cout << "INTEGERS: " << numInts << endl;
    return 0;
}
