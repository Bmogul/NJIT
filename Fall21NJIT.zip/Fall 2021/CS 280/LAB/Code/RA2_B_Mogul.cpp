#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <iomanip>
using namespace std;

int main(int argc, char const *argv[])
{

    /*
    Values to keep track of
    numLines - number of non-commented lined
    numLinesTotal - number of lines read
    longestLine - line of maximum length
    numWords - number of words
    longestWord - word of maximum length
    */
    int numLinesTotal = 0, numLines = 0, numWords = 0;
    string longestLine = "", longestWord = "";

    //opening requested file
    ifstream fileToRead;
    string fileName;
    cout << "Enter the name of a file to read from: " << endl;
    cin >> fileName;
    fileToRead.open(fileName.c_str());

    //if file cannot be opened
    if (!fileToRead)
    {
        cerr << "\nFile cannot be opened " << fileName << endl;
        exit(1);
    }

    //reading contents of the file
    while (fileToRead.good())
    {
        //reading line
        string currentLine;
        getline(fileToRead, currentLine);
        istringstream inputString(currentLine);

        //checking if line is not a comment
        string currentWord;
        inputString >> currentWord;
        if (currentWord != "#" && currentWord.find("//") == string::npos)
        {
            numLines++;

            //updating longest line
            if (currentLine.length() > longestLine.length())
                longestLine = currentLine;
            //looping through the line
            do
            {
                if (currentWord != "")
                {
                    numWords++;
                    //updating longest word
                    if (currentWord.length() > longestWord.length())
                        longestWord = currentWord;
                }

            } while (inputString >> currentWord);
        }

        numLinesTotal++;
    }

    cout << "Total Number of Lines: " << numLinesTotal - 1 << endl;
    cout << "Number of non-commented lines: " << numLines - 1 << endl;
    cout << "Line of Maximum Length: \"" << longestLine << "\"" << endl;
    cout << "Number of Words: " << numWords << endl;
    cout << "Word of Maximum Length: \"" << longestWord << "\"" << endl;

    return 0;
}
