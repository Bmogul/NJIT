#include <iostream>

using namespace std;

int main()
{
    string name;
    cout << "Welcome to CS 280." << endl;
    cout << "Enter yout name" << endl;
    getline(cin, name);
    cout << name;
    return 0;
}