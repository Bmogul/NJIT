#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <map>
#include "lex.cpp"

void RemoveDuplicates(std::vector<LexItem> &tokens);
void OrganizeTokens(std::vector<LexItem> &tokens);
void DetermineArgument(std::vector<std::string> &arguments, int index);
std::vector<std::string> CommandArguments(int argc, char **argv);

int main(int argc, char **argv)
{
}