#include <map>
#include <iostream>
#include <regex>
#include "lex.h"

static std::map<Token, std::string> tokenPrint{
    {PROGRAM, "PROGRAM"}, {WRITE, "WRITE"}, {INT, "INT"}, {END, "END"}, {IF, "IF"}, {FLOAT, "FLOAT"}, {STRING, "STRING"}, {REPEAT, "REPEAT"}, {BEGIN, "BEGIN"}, {IDENT, "IDENT"}, {ICONST, "ICONST"}, {RCONST, "RCONST"}, {SCONST, "SCONST"}, {PLUS, "PLUS"}, {MINUS, "MINUS"}, {MULT, "MULT"}, {DIV, "DIV"}, {REM, "REM"}, {ASSOP, "ASSOP"}, {LPAREN, "LPAREN"}, {RPAREN, "RPAREN"}, {COMMA, "COMMA"}, {EQUAL, "EQUAL"}, {GTHAN, "GTHAN"}, {SEMICOL, "SEMICOL"}, {ERR, "ERR"}, {DONE, "DONE"}};

int main(int argc, char const *argv[])
{
    /* code */
    return 0;
}

ostream &operator<<(ostream &out, const LexItem &tok)
{
    std::string *token = &tokenPrint[tok.GetToken()];
    std::cout << *token;

    bool eval = (tok.GetToken() == SCONST) || (tok.GetToken() == RCONST) ||
                (tok.GetToken() == ICONST) || (tok.GetToken() == IDENT) ||
                (tok.GetToken() == ERR);

    if (eval)
        std::cout << " (" << tok.GetLexeme() << ")";
    return out;
}

LexItem currentToken;
LexItem previousToken;

LexItem getNextToken(istream &in, int &linenumber)
{

    enum TokenState
    {
        START,
        INID,
        INSTRING,
        ININT,
        INREAL,
        INCOMMENT,
        SIGN
    } lexstate = START;
    std::string lexeme;
    char character;

    while (in.get(character))
    {
        switch (lexstate)
        {
        case START:
            if (character == '\n')
                linenumber++;
            if (in.peek() == -1)
            {
                if (previousToken.GetToken() != END)
                    return LexItem(ERR, "No END Token", previousToken.GetLinenum());
                return LexItem(DONE, lexeme, linenumber);
            }
            if (std::isspace(character))
                continue;

            lexeme = character;
            if (lexeme == "/" && char(in.peek()) == '/')
            {
                lexstate = INCOMMENT;
                continue;
            }

            if (character == '+' || character == '-' || character == '*' || character == '/' ||
                character == '%' || character == '=' || character == '(' || character == ')' ||
                (lexeme == "==") || character == ',' || character == ';')
            {
                lexstate = SIGN;
                continue;
            }

            if (character == '\"')
            {
                lexstate = INSTRING;
                continue;
            }

            if (std::isdigit(character))
            {
                lexstate = ININT;
                continue;
            }

            if (character == '.')
            {
                lexstate = INREAL;
                continue;
            }

            if (std::isalpha(character))
            {
                lexstate = INID;
                continue;
            }

            return LexItem(ERR, lexeme, linenumber);

        case INID:
            if (std::regex_match(lexeme + character, std::regex("[a-zA-Z][a-zA-Z0-9]*")))
                lexeme += character;
            if (in.peek() == -1 || !std::regex_match(lexeme + character, std::regex("[a-zA-Z][a-zA-Z0-9]*")))
            {
                lexstate = START;
                in.putback(character);

                if (lexeme == "begin")
                {
                    if (previousToken.GetToken() != ERR)
                        return LexItem(ERR, lexeme, linenumber);
                    currentToken = LexItem(BEGIN, lexeme, linenumber);
                }
                else if (lexeme == "program")
                    currentToken = LexItem(PROGRAM, lexeme, linenumber);
                else if (lexeme == "end")
                {
                    if (previousToken.GetToken() != SEMICOL)
                        return LexItem(ERR, previousToken.GetLexeme(), linenumber);
                    currentToken = LexItem(END, lexeme, linenumber);
                }
                else if (lexeme == "write")
                    currentToken = LexItem(WRITE, lexeme, linenumber);
                else if (lexeme == "int")
                    currentToken = LexItem(INT, lexeme, linenumber);
                else if (lexeme == "float")
                    currentToken = LexItem(FLOAT, lexeme, linenumber);
                else if (lexeme == "string")
                    currentToken = LexItem(STRING, lexeme, linenumber);
                else if (lexeme == "repeat")
                    currentToken = LexItem(REPEAT, lexeme, linenumber);
                else if (lexeme == "if")
                    currentToken = LexItem(IF, lexeme, linenumber);
                else
                {
                    if (previousToken.GetToken() == IDENT)
                    {
                        return LexItem(ERR, lexeme, linenumber);
                    }
                    currentToken = LexItem(IDENT, lexeme, linenumber);
                }

                if (currentToken != BEGIN && previousToken == ERR)
                    return LexItem(ERR, "No BEGIN Token", currentToken.GetLinenum());
                previousToken = currentToken;
                return currentToken;
            }
            break;

        case INSTRING:
            if (previousToken == ERR)
                return LexItem(ERR, "No Begin Token", linenumber);
            if (character == 10)
                return LexItem(ERR, lexeme, linenumber);

            if (std::regex_match(lexeme + character, std::regex("\"[ -~]*")))
            {
                if (character == '\\' && in.peek() == '\"')
                {
                    lexeme += character;
                    in.get(character);
                    lexeme += character;
                    continue;
                }
                else
                    lexeme += character;
            }

            if (std::regex_match(lexeme + character, std::regex("\"[ -~]*\"")))
            {
                lexstate = START;
                currentToken = LexItem(SCONST, lexeme, linenumber);
                previousToken = currentToken;
                return currentToken;
            }
            break;

        case ININT:
            if (previousToken == ERR)
                return LexItem(ERR, "No Begin Token", linenumber);
            if (std::isalpha(character))
                return LexItem(ERR, lexeme + character, linenumber);
            if (std::regex_match(lexeme + character, std::regex("[0-9]+")))
            {
                lexeme += character;
            }
            else if (character == '.')
            {
                lexstate = INREAL;
                in.putback(character);
                continue;
            }
            else
            {
                lexstate = START;
                in.putback(character);
                currentToken = LexItem(ICONST, lexeme, linenumber);
                previousToken = currentToken;
                return currentToken;
            }
            break;

        case INREAL:
            if (previousToken == ERR)
                return LexItem(ERR, "No Begin Token", linenumber);
            if (std::isalpha(character))
                return LexItem(ERR, lexeme + character, linenumber);
            if (std::regex_match(lexeme + character, std::regex("[0-9]*\\.[0-9]+")))
            {
                lexeme += character;
            }
            else if (std::regex_match(lexeme + character, std::regex("[0-9]*\\.[0-9]*")))
            {
                lexeme += character;
            }
            else
            {
                if (lexeme[lexeme.length() - 1] == '.')
                    return LexItem(ERR, lexeme, linenumber);
                lexstate = START;
                in.putback(character);
                currentToken = LexItem(RCONST, lexeme, linenumber);
                previousToken = currentToken;
                return currentToken;
            }
            break;

        case INCOMMENT:
            if (character == '\n')
            {
                linenumber++;
                lexstate = START;
            }
            continue;

        case SIGN:
            if (previousToken == ERR)
                return LexItem(ERR, "No Begin Token", linenumber);

            if (lexeme == "+" || lexeme == "*" || lexeme == "/" || lexeme == "%" || lexeme == ">" || lexeme == "==")
            {
                Token token = previousToken.GetToken();
                if (token == IDENT || token == ICONST || token == RCONST)
                {
                    lexstate = START;
                    in.putback(character);
                    if (lexeme == "+")
                        currentToken = LexItem(PLUS, lexeme, linenumber);
                    else if (lexeme == "*")
                        currentToken = LexItem(MULT, lexeme, linenumber);
                    else if (lexeme == "/")
                        currentToken = LexItem(DIV, lexeme, linenumber);
                    else if (lexeme == "%")
                        currentToken = LexItem(REM, lexeme, linenumber);
                    else if (lexeme == ">")
                        currentToken = LexItem(GTHAN, lexeme, linenumber);
                    else
                        currentToken = LexItem(EQUAL, lexeme, linenumber);
                    previousToken = currentToken;
                    return currentToken;
                }
                else
                    return LexItem(ERR, lexeme + character, linenumber);
            }

            if (lexeme == "-")
            {
                Token token = previousToken.GetToken();
                if (token == IDENT || token == ICONST || token == RCONST || token == ASSOP)
                {
                    lexstate = START;
                    in.putback(character);
                    currentToken = LexItem(MINUS, lexeme, linenumber);
                    previousToken = currentToken;
                    return currentToken;
                }
                else
                    return LexItem(ERR, lexeme + character, linenumber);
            }
            if (lexeme == "(")
            {
                Token token = previousToken.GetToken();
                if (token == IF || token == ASSOP || token == PLUS || token == MINUS ||
                    token == MULT || token == DIV || token == REM)
                {
                    lexstate = START;
                    in.putback(character);
                    currentToken = LexItem(LPAREN, lexeme, linenumber);
                    previousToken = currentToken;
                    return currentToken;
                }
                else
                    return LexItem(ERR, lexeme + character, linenumber);
            }
            if (lexeme == ")")
            {
                Token token = previousToken.GetToken();
                if (token == ICONST || token == RCONST || token == IDENT)
                {
                    lexstate = START;
                    in.putback(character);
                    currentToken = LexItem(RPAREN, lexeme, linenumber);
                    previousToken = currentToken;
                    return currentToken;
                }
                else
                    return LexItem(ERR, lexeme + character, linenumber);
            }
            if (lexeme == ",")
            {
                Token token = previousToken.GetToken();
                if (token == SCONST)
                {
                    lexstate = START;
                    in.putback(character);
                    currentToken = LexItem(COMMA, lexeme, linenumber);
                    previousToken = currentToken;
                    return currentToken;
                }
                else
                    return LexItem(ERR, lexeme + character, linenumber);
            }
            if (lexeme == ";")
            {
                Token token = previousToken.GetToken();
                if (token == SCONST || token == ICONST || token == RCONST || token == IDENT)
                {
                    lexstate = START;
                    in.putback(character);
                    currentToken = LexItem(SEMICOL, lexeme, linenumber);
                    previousToken = currentToken;
                    return currentToken;
                }
                else
                    return LexItem(ERR, lexeme + character, linenumber);
            }
            break;
        }
    }
    return LexItem(DONE, "", linenumber);
}