function [count, list] = tclip(a,b,c)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   The function tclip analyzes the intersection of the solutions set
%   of ax+by=c with the "solid" triangle with vertices (0,0), (0,1), (1,0).
%
%   The return value count is
%        -2 if the solution set of ax+by=c is empty,
%        -1 if the solution set of ax+by=c is the plane,
%         0 if the line fails to intersect the triangle,
%         1 if the line intersects the triangle in one point,
%         2 if the line intersects the triangle in infinitely many points.
%
%   The return value list is
%         an empty list of 2-component column vectors if count<= 0
%         a 2-component column vector with the coordinates of intersection
%             if count==1,
%         a 2x2 array (list of two 2-component column vectors) with the
%             endpoints of the intersection if count==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    count = 0;           % default return value  
    list = zeros(2,0);   % default return value (empty list)

    %%%%%%%%%%%%%%%%%%%%%%%% CASE 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if a==0 && b==0      % CASE 0:  solution set not a line

        if c == 0        % solution set is the plane
            count = -1;
        else             % solution set is empty
            count = -2; 
        end
               
        return

    end
    
    %%%%%%%%%%%%%%%%%%%%%%%% CASE 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if a==0 && b~=0      % CASE 1:  horizontal line

        y = c/b;

        if 0<=y 
            if y<1       % infinite intersection
                count = 2;
                list = [0 1-y; y y];
            elseif y==1  % singleton intersection
                count = 1;
                list = [0; 1];
            end
        end

        return
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%% CASE 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if a~=0 && b==0       % CASE 2:  vertical line

        % Insert code needed to handle the case of a vertical line
        x = c/a;
        if x >= 0
            if x<1
                count = 2;
                list = [x x;1-x 0];
            elseif x==1
                count = 1;
                list = [1;0];
            end
        end
        return
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%% CASE 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if a-b == 0 && a~=0         % CASE 3:  line parallel to hypotenuse

        % Insert code needed to handle the case of a line parallel to the hypotenues
        
        if c == 0
            count = 1;
            list = [0,0];
        elseif c <= a
            count = 2;
            list = [0 c/a; c/a 0];
        end
        return
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%% CASE 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if a~=0 && b~=0 && a+b~=0   %  CASE 4:   generic line
        
        % check intersection with the y-axis (x=0)

        y = c/b;

        if 0<=y && y<1                  %removed <= with < 0 y
            count = count + 1;
            list(:,count) = [0; y];
        end

        % check intersection with the x-axis (y=0)
        
        x = c/a;
        if 0<x && x<1
            count = count +1;
            list(:,count) = [x;0];
        end

        %%%% Code to process the intersection with the x-axis is needed here.

        % check intersection with the hypotenuse (x+y=1)
        
        %%%% Code to process the intersection with the hypotenuse is needed here.
        sol = linsolve([a b; 1 1], [c;1]);
        if sol(1) <= 1 && sol(1) >= 0 && sol(2) <= 1 && sol(2) >= 0
            count = count +1;
            list(:,count) = linsolve([a b; 1 1], [c;1]);
        end
        
        return
    end
end

