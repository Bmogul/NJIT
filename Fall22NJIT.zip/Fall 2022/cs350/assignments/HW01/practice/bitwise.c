#include <stdio.h>

int main(){

	// & AND, two numbers and does AND of every bit, 1 if both 1 0 otherwise
	// | OR, two numbers, OR for every bit, 1 if one 1, 0 if no 1
	// ^ XOR, only 1 when one is 1 and the other is 0, else 0
	// << left shift, shifts left operand n bits (defined by r operand
	// >> right shift, same as left but right
	// ~ NOT, inverts all bits
	//
	//
	
	unsigned char a =5, b =9;
	printf("a: %d, b: %d\n", a, b);
	printf("a&b: %d\n", a&b);
	printf("a|b: %d\n", a|b);

	printf("a^b: %d\n", a^b);

	printf("~a: %d\n", ~a);
	printf("b<<1: %d\n", b<<1);
	printf("b>>1: %d\n", b>>1);


	
	return 0;
}
