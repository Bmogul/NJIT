#include <stdio.h>
#include <math.h>

//	Cellular Automaton
// model of a colony of cells
// cells are 1d
// cells are either 1 or 0, alive or dead
// neighborhoods are formed of a cell and a cell to its left and right
//
// given intial state, simulate birth and death of future generation of cells
// cells states updated with bitwise operations
//
// neighborhoods are effectivly 3-bit numebers, only 8 configurations
// 	111	110	101	100	011	010	001	000
// 	 0	 1	 0	 1	 1	 0	 1	 0
int main(){
	
	// 32nd bit is 1, all others are 0
	unsigned long automaton = 4294967296;
	unsigned long pattern = 0x5A;
	unsigned short int currentBit = 0;
	unsigned long bitCompare = 1;
	int i = 0;
	for(i = 0; i < 2; i++){
		unsigned long temp = automaton;
		bitCompare = 1;
		currentBit = 0;

		// print automaton

		// change autamton

		while(currentBit < 64){
			int centerValue = automaton & bitCompare ? 1 : 0;
			int leftValue = bitCompare << 1 ? automaton & (bitCompare << 1) ? 1 : 0 : 0 ;
			int rightValue = bitCompare >> 1? automaton & (bitCompare >> 1)? 1: 0: 0;
			int index = (leftValue*(4)) + (centerValue*2) + (rightValue*1);
			
			int mask = 1 << currentBit;

			unsigned long changedBit = (pattern >> index ? 1: 0);
		//	printf("changedBit value :%d\n", changedBit);
			
			temp = temp^changedBit;
		//	printf("current Bit: %d, 0x5A right shifted by %d: %lu\n", currentBit, index, pattern>>index);
		//	printf("right, center, left: %d, %d, %d\n", rightValue, centerValue, leftValue);
		//	printf("bitComprae: %lu\n\n", bitCompare);

			if(temp & bitCompare)
				printf("#");
			else
				printf("0");
			currentBit++;
			bitCompare = bitCompare << 1;
		//automaton = automaton >> 1
		}
		printf("\n");
		automaton = temp;
	}

	printf("0x5A right shift 7: %lu\n", pattern >> 7 & 0x01 );
	printf("0x5A right shift 7: %lu\n", pattern >> 6 & 0x01);
	printf("0x5A right shift 7: %lu\n", pattern >> 5 & 0x01);
	printf("0x5A right shift 7: %lu\n", pattern >> 4 & 0x01);
	printf("0x5A right shift 7: %lu\n", pattern >> 3 & 0x01);
	printf("0x5A right shift 7: %lu\n", pattern >> 2 & 0x01);
	printf("0x5A right shift 7: %lu\n", pattern >> 1 & 0x01);

	printf("\n");

	return 0;
}
