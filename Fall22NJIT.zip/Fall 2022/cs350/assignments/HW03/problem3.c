
long reverse_engineer(long a, long b, long c){

	if(a >= b){
		if(b <= c )
			return b+c;
		else 
			return c-b;
	}else if(a <= c){
		return a+b;
	}

	return c-a;
}
