int loop(int a, int b, int c, int d){
	int e;
	int f = 0;
	for(e = b; e < c ; e += d){
		if(a <= e)
			break;
		f++;
	}
	return (a==e && e < c) ? f : -1;
}
